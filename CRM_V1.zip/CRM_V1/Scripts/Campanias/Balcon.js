﻿var datos;
function SetBalconData(Id, FolioBalcon, TelTrabajoBalcon, Celular2Balcon, LineaActualBalcon, LineaNuevaBalcon,
    IncrementoBalcon, ProductoBalcon, Ult4DgtBalcon, TasaAnualBalcon, CatBalcon, FechaCatBalcon, MontoMaximoBalcon,
    TipoLlamadaBalcon, GepcBalcon, NombreBanco1Balcon, Plazo1Balcon, CantTransferencia1Balcon, Plazo2Balcon, NombreBanco2Balcon,
    CantTransferencia2Balcon, Plazo3Balcon, NombreBanco3Balcon, CantTransferencia3Balcon, Plazo4Balcon,
    NombreBanco4Balcon, CantTransferencia4Balcon, Plazo5Balcon, NombreBanco5Balcon, CantTransferencia5Balcon, EstatusBalcon,
    EstatusVenta, FechaVenta, EstadoSucursal, MunicipioSucursal, FechaVicitaSucursalBN, SucursalBN, NumeroSucursalBN,
    RegionalBN, DivisionBN) {

    loadTipoLlamada(TipoLlamadaBalcon);
    loadBancos(NombreBanco1Balcon, NombreBanco2Balcon, NombreBanco3Balcon, NombreBanco4Balcon, NombreBanco5Balcon);
    loadPlazosBalcon(Plazo1Balcon, Plazo2Balcon, Plazo3Balcon, Plazo4Balcon, Plazo5Balcon);
    $("#IdBalcon").val(Id);
    $("#FolioBalcon").val(FolioBalcon);
    $("#TelTrabajoBalcon").val(TelTrabajoBalcon);
    $("#Celular2Balcon").val(Celular2Balcon);
    $("#LineaActualBalcon").val(LineaActualBalcon);
    $("#LineaNuevaBalcon").val(LineaNuevaBalcon);
    $("#IncrementoBalcon").val(IncrementoBalcon);
    $("#ProductoBalcon").val(ProductoBalcon);
    $("#Ult4DgtBalcon").val(Ult4DgtBalcon);
    $("#TasaAnualBalcon").val(TasaAnualBalcon);
    $("#CatBalcon").val(CatBalcon);
    $("#FechaCatBalcon").val(formatDate(FechaCatBalcon));

    $("#MontoMaximoBalcon").val(MontoMaximoBalcon);
    $("#GepcBalcon").val(GepcBalcon);
    $("#CantTransferencia1Balcon").val(CantTransferencia1Balcon);
    $("#CantTransferencia2Balcon").val(CantTransferencia2Balcon);
    $("#CantTransferencia3Balcon").val(CantTransferencia3Balcon);
    $("#CantTransferencia4Balcon").val(CantTransferencia4Balcon);
    $("#CantTransferencia5Balcon").val(CantTransferencia5Balcon);
    $("#EstatusBalcon").val(EstatusBalcon);
    $("#FechaVentaBalcon").val(formatDate(FechaVenta));

    $("#SucursalBN").val(SucursalBN);
    $("#NumeroSucursalBN").val(NumeroSucursalBN);
    $("#RegionalBN").val(RegionalBN);
    $("#DivisionBN").val(DivisionBN);

    $("#StatusSaleBalcon").html(ComboCatalogo());
    $("#StatusSaleBalcon").val(0);
    document.getElementById("SaveBalcon").onclick = function () {
        ValidateBalconData();
    }
    document.getElementById("ValidateBalcon").onclick = function () {
        ValidarVenta();
    }


    //cargar estados para las sucursales Balcon
    estados("EstadoSucursalBN", EstadoSucursal, 0);
    LoadMunicipios(EstadoSucursal, MunicipioSucursal, 'MunicipioSucursalBN');
    $("#EstadoSucursalBN").change(function (evt) {
        var item = $(this).val();
        LoadMunicipios(item, 0, 'MunicipioSucursalBN');
    });

    $("#MunicipioSucursalBN").change(function (evt) {
        var item = $(this).val();
        var fechVicSuc = $("#FechaVicitaSucursalBN").val();
        if (fechVicSuc === "") {
            alert("Seleccione fecha visita sucursal");
            $("#FechaVicitaSucursalBN").focus();
            return;
        }

        if (item === "0") {
            alert("Seleccione un municipio");
            $("#MunicipioSucursalBN").focus();
            return;
        }

        var dia = diaSemana(fechVicSuc);
        if (dia === 'sab') {
            FinloadBranchOfficeBalcon(item, 1);
        } else {
            FinloadBranchOfficeBalcon(item, 0);
        }
    })

    var cal = dataCalendar;
		if (datos === undefined)
	{
	}
	else 	
	{
		delete datos;
	}
    switch (EstatusVenta) {
        case -1://no se ha tocado
        case 2://no venta
            var currentDate = new Date();
            cal['beforeShowDay'] = function (day) {
                var day = day.getDay();
                if (day == 0) {
                    return [false, "somecssclass"]
                }
                return [true, "someothercssclass"]
            }
            var fexhMas = '+' + sumaDias(currentDate) + 'D';
            cal['minDate'] = '+0D';
            cal['maxDate'] = fexhMas;
            var day = currentDate.getDate();
            var monthIndex = currentDate.getMonth();
            var year = currentDate.getFullYear();
            var fecha = year + "/" + (monthIndex + 1) + "/" + day;

            $("#FechaVicitaSucursalBN").datepicker(cal);
            $("#FechaVicitaSucursalBN").val(fecha);

            noVendido("EstadoBalcon", "HeadingBalcon", "ValidarBalcon", "SaveBalcon");
            setFieldsBalcon("");
            break;
        case 0://ya se vendio, no se ha validado
            $("#FechaVicitaSucursalBN").val(formatDate(FechaVicitaSucursalBN));
            $("#FechaVicitaSucursalBN").datepicker(cal);

            noValidado("EstadoBalcon", "HeadingBalcon", "ValidarBalcon", "SaveBalcon");
            var Id = $("#IdBalcon");
            var FolioBalcon = $("#FolioBalcon");
            var TelTrabajoBalcon = $("#TelTrabajoBalcon");
            var Celular2Balcon = $("#Celular2Balcon");
            var LineaActualBalcon = $("#LineaActualBalcon");
            var LineaNuevaBalcon = $("#LineaNuevaBalcon");
            var IncrementoBalcon = $("#IncrementoBalcon");
            var ProductoBalcon = $("#ProductoBalcon");
            var Ult4DgtBalcon = $("#Ult4DgtBalcon");
            var TasaAnualBalcon = $("#TasaAnualBalcon");
            var CatBalcon = $("#CatBalcon");
            var FechaCatBalcon = $("#FechaCatBalcon");
            var MontoMaximoBalcon = $("#MontoMaximoBalcon");
            var TipoLlamadaBalcon = $("#TipoLlamadaBalcon");
            var GepcBalcon = $("#GepcBalcon");
            var NombreBanco1Balcon = $("#NombreBanco1Balcon");
            var Plazo1Balcon = $("#Plazo1Balcon");
            var CantTransferencia1Balcon = $("#CantTransferencia1Balcon");
            var Plazo2Balcon = $("#Plazo2Balcon");
            var NombreBanco2Balcon = $("#NombreBanco2Balcon");
            var CantTransferencia2Balcon = $("#CantTransferencia2Balcon");
            var Plazo3Balcon = $("#Plazo3Balcon");
            var NombreBanco3Balcon = $("#NombreBanco3Balcon");
            var CantTransferencia3Balcon = $("#CantTransferencia3Balcon");
            var Plazo4Balcon = $("#Plazo4Balcon");
            var NombreBanco4Balcon = $("#NombreBanco4Balcon");
            var CantTransferencia4Balcon = $("#CantTransferencia4Balcon");
            var Plazo5Balcon = $("#Plazo5Balcon");
            var NombreBanco5Balcon = $("#NombreBanco5Balcon");
            var CantTransferencia5Balcon = $("#CantTransferencia5Balcon");
            var EstatusBalcon = $("#EstatusBalcon");
            var FechaVentaBalcon = $("#FechaVentaBalcon");
            var NumeroCliente = $("#Cliente");
            var Nombres = $("#Nombres");
            var ApellidoPaterno = $("#ApellidoPaterno");
            var ApellidoMaterno = $("#ApellidoMaterno");
            var FechaNacimiento = $("#FechaNacimiento");
            var RFC = $("#RFC");
            var Calle = $("#Calle");
            var NumeroExterior = $("#NumeroExterior");
            var NumeroInterior = $("#NumeroInterior");
            var CodigoPostal = $("#CodigoPostal");
            var Colonia = $("#Colonia");
            var Municipios = $("#Municipio");
            var Estados = $("#Estado");
            var Celular = $("#Celular");
            var TelefonoCasa = $("#TelefonoCasa");

            var FechaVicitaSucursalBN = $("#FechaVicitaSucursalBN");
            var SucursalBN = $("#SucursalBN");
            var NumeroSucursalBN = $("#NumeroSucursalBN");
            var RegionalBN = $("#RegionalBN");


            datos = {
                Id: Id.val(),
                NumeroCliente: NumeroCliente.val(),
                Nombre: Nombres.val(),
                ApellidoPaterno: ApellidoPaterno.val(),
                ApellidoMaterno: ApellidoMaterno.val(),
                FechaNacimiento: FechaNacimiento.val(),
                RFC: RFC.val(),
                Calle: Calle.val(),
                NumeroExterior: NumeroExterior.val(),
                NumeroInterior: NumeroInterior.val(),
                CodigoPostal: CodigoPostal.val(),
                Colonia: Colonia.val(),
                Municipio: Municipios.val(),
                Estado: Estados.val(),
                Celular: Celular.val(),
                TelefonoCasa: TelefonoCasa.val(),

                Folio: FolioBalcon.val(),
                TelTrabajo: TelTrabajoBalcon.val(),
                Celular2: Celular2Balcon.val(),
                LineaActual: LineaActualBalcon.val(),
                LineaNueva: LineaNuevaBalcon.val(),
                Incremento: IncrementoBalcon.val(),
                Producto: ProductoBalcon.val(),
                Ult4DGT: Ult4DgtBalcon.val(),
                TasaAnual: TasaAnualBalcon.val(),
                Cat: CatBalcon.val(),
                FechaCat: FechaCatBalcon.val(),
                MontoMaximo: MontoMaximoBalcon.val(),
                TipoLlamada: TipoLlamadaBalcon.val(),
                Gepc: GepcBalcon.val(),
                Plazo1: Plazo1Balcon.val(),
                NombreBanco1: NombreBanco1Balcon.val(),
                CantTransferencia1: CantTransferencia1Balcon.val(),
                Plazo2: Plazo2Balcon.val(),
                NombreBanco2: NombreBanco2Balcon.val(),
                CantTransferencia2: CantTransferencia2Balcon.val(),
                Plazo3: Plazo3Balcon.val(),
                NombreBanco3: NombreBanco3Balcon.val(),
                CantTransferencia3: CantTransferencia3Balcon.val(),
                Plazo4: Plazo4Balcon.val(),
                NombreBanco4: NombreBanco4Balcon.val(),
                CantTransferencia4: CantTransferencia4Balcon.val(),
                Plazo5: Plazo5Balcon.val(),
                NombreBanco5: NombreBanco5Balcon.val(),
                CantTransferencia5: CantTransferencia5Balcon.val(),
                Estatus: EstatusBalcon.val(),
                FechaVenta: FechaVentaBalcon.val(),
            };
            break;
        case 1://venta exitosa
            $("#FechaVicitaSucursalBN").val(formatDate(FechaVicitaSucursalBN));
            ventaExitosa("EstadoBalcon", "HeadingBalcon", "ValidarBalcon", "SaveBalcon");
            setFieldsBalcon("enabled");
            break;
    }
    $("#FechaVentaBalcon").datepicker(dataCalendarCopy);
    $("#FechaCatBalcon").datepicker(dataCalendarCopy);

    document.getElementById("OpenScriptBalcon").onclick = function () {
        window.open(hostInit + '/Client/OpenPdf/BALCON', '_blank', 'location=no, resizable=si', true);
    }
    ValidarGrupo();
}

function loadTipoLlamada(value) {
    $.ajax({
        url: hostInit + '/Client/loadTipoLlamada',
        contentType: 'application/json;charset=utf-8',
        success: function (resolve) {
            for (var i in resolve) {
                document.getElementById("TipoLlamadaBalcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
            }
            var val = (value === "" || value == null) ? 0 : value;
            document.getElementById("TipoLlamadaBalcon").value = val;
        },
        error: function (reject) {
            console.log(reject);
        }
    });
}

function loadPlazosBalcon(value1, value2, value3, value4, value5) {
    value1 = (value1 === "" || value1 == null) ? 0 : value1;
    value2 = (value2 === "" || value2 == null) ? 0 : value2;
    value3 = (value3 === "" || value3 == null) ? 0 : value3;
    value4 = (value4 === "" || value4 == null) ? 0 : value4;
    value5 = (value5 === "" || value5 == null) ? 0 : value5;
    $.ajax({
        url: hostInit + '/Client/loadPlazos',
        contentType: 'application/json;charset=utf-8',
        success: function (resolve) {
            for (var i in resolve) {
                document.getElementById("Plazo1Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("Plazo2Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("Plazo3Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("Plazo4Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("Plazo5Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);

            }
            document.getElementById("Plazo1Balcon").value = value1;
            document.getElementById("Plazo2Balcon").value = value2;
            document.getElementById("Plazo3Balcon").value = value3;
            document.getElementById("Plazo4Balcon").value = value4;
            document.getElementById("Plazo5Balcon").value = value5;
        },
        error: function (reject) {
            console.log(reject);
        }
    });
}

function loadBancos(value1, value2, value3, value4, value5) {
    //24 ecm, 35 disponible
    value1 = (value1 === "" || value1 == null) ? 0 : value1;
    value2 = (value2 === "" || value2 == null) ? 0 : value2;
    value3 = (value3 === "" || value3 == null) ? 0 : value3;
    value4 = (value4 === "" || value4 == null) ? 0 : value4;
    value5 = (value5 === "" || value5 == null) ? 0 : value5;
    $.ajax({
        url: hostInit + '/Client/loadBancos',
        contentType: 'application/json;charset=utf-8',
        success: function (resolve) {
            for (var i in resolve) {
                document.getElementById("NombreBanco1Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("NombreBanco2Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("NombreBanco3Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("NombreBanco4Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
                document.getElementById("NombreBanco5Balcon").options[i] = new Option(resolve[i].Texto, resolve[i].Valor);
            }
            document.getElementById("NombreBanco1Balcon").value = value1;
            document.getElementById("NombreBanco2Balcon").value = value2;
            document.getElementById("NombreBanco3Balcon").value = value3;
            document.getElementById("NombreBanco4Balcon").value = value4;
            document.getElementById("NombreBanco5Balcon").value = value5;
        },
        error: function (reject) {
            console.log(reject);
        }
    });
}

function ValidarVenta() {
    var UserName = $("#UserBalcon");
    var Password = $("#PasswordBalcon");

    if (UserName.val() === "") {
        UserName.focus();
        return;
    }
    if (Password.val() === "") {
        Password.focus();
        return;
    }
    var json = {
        UserName: UserName.val(),
        Password: Password.val()
    };
    var itemSelect = document.getElementById("StatusSaleBalcon");
    if (itemSelect.options[itemSelect.selectedIndex].value == 0) {
        alert("Debe seleccionar un estado de la venta al validar");
        return;
    }
    showLoader();
    $.ajax({
        url: hostInit + "/User/LogIn",
        type: 'POST',
        crossDomain: 'true',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            if (response === "No existe") {
                alert("Usuario o contraseña incorrecto(s)");
                UserName.val("");
                Password.val("");
                UserName.focus();
                hideLoader();
                return;
            }
            if (response['Tipo'] == 6) {
                datos['EstatusVenta'] = $("#StatusSaleBalcon").val();
                $.ajax({
                    url: hostInit + '/Client/SaveBalconData',
                    type: 'POST',
                    contentType: 'application/json;charset=utf-8',
                    data: JSON.stringify(datos),
                    success: function (response) {
                        if (datos['EstatusVenta'] == 2) {
                            noVendido("EstadoBalcon", "HeadingBalcon", "ValidarBalcon", "SaveBalcon");
                            ValidarGrupo();
                        } else {
                            ventaExitosa("EstadoBalcon", "HeadingBalcon", "ValidarBalcon", "SaveBalcon");
                            setFieldsCnc("disabled");
                            $("#collapse9").collapse('hide');
                        }
                        $("#StatusSaleBalcon").val(0)
                        hideLoader();
                    },
                    error: function (error) {
                        console.log("Ocurrio un error al guardar los dao");
                        hideLoader();
                    }
                });
            } else {
                alert("No tiene los privilegios de validador");
                hideLoader();
            }
            UserName.val("");
            Password.val("");
        },
        error: function (error) {
            alert("error al entrar como validador");
            hideLoader();
        }
    });
}

function setFieldsBalcon(value) {
    $("#IdBalcon").prop("disabled", value);
    $("#TelTrabajoBalcon").prop("disabled", value);
    $("#Celular2Balcon").prop("disabled", value);
    $("#LineaActualBalcon").prop("disabled", value);
    $("#LineaNuevaBalcon").prop("disabled", value);
    $("#IncrementoBalcon").prop("disabled", value);
    $("#ProductoBalcon").prop("disabled", value);
    $("#Ult4DgtBalcon").prop("disabled", value);
    $("#TasaAnualBalcon").prop("disabled", value);
    $("#CatBalcon").prop("disabled", value);
    $("#FechaCatBalcon").prop("disabled", value);
    $("#MontoMaximoBalcon").prop("disabled", value);
    $("#TipoLlamadaBalcon").prop("disabled", value);
    $("#GepcBalcon").prop("disabled", value);
    $("#NombreBanco1Balcon").prop("disabled", value);
    $("#Plazo1Balcon").prop("disabled", value);
    $("#CantTransferencia1Balcon").prop("disabled", value);
    $("#Plazo2Balcon").prop("disabled", value);
    $("#NombreBanco2Balcon").prop("disabled", value);
    $("#CantTransferencia2Balcon").prop("disabled", value);
    $("#Plazo3Balcon").prop("disabled", value);
    $("#NombreBanco3Balcon").prop("disabled", value);
    $("#CantTransferencia3Balcon").prop("disabled", value);
    $("#Plazo4Balcon").prop("disabled", value);
    $("#NombreBanco4Balcon").prop("disabled", value);
    $("#CantTransferencia4Balcon").prop("disabled", value);
    $("#Plazo5Balcon").prop("disabled", value);
    $("#NombreBanco5Balcon").prop("disabled", value);
    $("#CantTransferencia5Balcon").prop("disabled", value);
    $("#EstatusBalcon").prop("disabled", value);
    $("#FechaVentaBalcon").prop("disabled", value);

    $("#EstadoSucursalBN").prop("disabled", value);
    $("#MunicipioSucursalBN").prop("disabled", value);
    $("#FechaVicitaSucursalBN").prop("disabled", value);
    $("#SucursalBN").prop("disabled", value);
    $("#NumeroSucursalBN").prop("disabled", value);
    $("#RegionalBN").prop("disabled", value);

    $("#DivisionBN").prop("disabled", value);
}

function ValidateBalconData() {
    var Id = $("#IdBalcon");
    var FolioBalcon = $("#FolioBalcon");
    var TelTrabajoBalcon = $("#TelTrabajoBalcon");
    var Celular2Balcon = $("#Celular2Balcon");
    var LineaActualBalcon = $("#LineaActualBalcon");
    var LineaNuevaBalcon = $("#LineaNuevaBalcon");
    var IncrementoBalcon = $("#IncrementoBalcon");
    var ProductoBalcon = $("#ProductoBalcon");
    var Ult4DgtBalcon = $("#Ult4DgtBalcon");
    var TasaAnualBalcon = $("#TasaAnualBalcon");
    var CatBalcon = $("#CatBalcon");
    var FechaCatBalcon = $("#FechaCatBalcon");
    var MontoMaximoBalcon = $("#MontoMaximoBalcon");
    var TipoLlamadaBalcon = $("#TipoLlamadaBalcon");
    var GepcBalcon = $("#GepcBalcon");
    var NombreBanco1Balcon = $("#NombreBanco1Balcon");
    var Plazo1Balcon = $("#Plazo1Balcon");
    var CantTransferencia1Balcon = $("#CantTransferencia1Balcon");
    var Plazo2Balcon = $("#Plazo2Balcon");
    var NombreBanco2Balcon = $("#NombreBanco2Balcon");
    var CantTransferencia2Balcon = $("#CantTransferencia2Balcon");
    var Plazo3Balcon = $("#Plazo3Balcon");
    var NombreBanco3Balcon = $("#NombreBanco3Balcon");
    var CantTransferencia3Balcon = $("#CantTransferencia3Balcon");
    var Plazo4Balcon = $("#Plazo4Balcon");
    var NombreBanco4Balcon = $("#NombreBanco4Balcon");
    var CantTransferencia4Balcon = $("#CantTransferencia4Balcon");
    var Plazo5Balcon = $("#Plazo5Balcon");
    var NombreBanco5Balcon = $("#NombreBanco5Balcon");
    var CantTransferencia5Balcon = $("#CantTransferencia5Balcon");
    var EstatusBalcon = $("#EstatusBalcon");
    var FechaVentaBalcon = $("#FechaVentaBalcon");
    var FechaVicitaSucursalBN = $("#FechaVicitaSucursalBN");
    var SucursalBN = $("#SucursalBN");
    var NumeroSucursalBN = $("#NumeroSucursalBN");
    var RegionalBN = $("#RegionalBN");

    var DivisionBN = $("#DivisionBN");

    /*if (FolioBalcon.val() === "") {
        alert("Ingrese folio");
        FolioBalcon.focus();
        return;
    }*/

    if (TelTrabajoBalcon.val() === "") {
        alert("Ingrese telefono del trabajo");
        TelTrabajoBalcon.focus();
        return;
    }
    if (Celular2Balcon.val() === "") {
        alert("Ingrese celular");
        Celular2Balcon.focus();
        return;
    }
    if (LineaActualBalcon.val() === "") {
        alert("Ingrese LineaActualBalcon");
        LineaActualBalcon.focus();
        return;
    }
    if (LineaNuevaBalcon.val() === "") {
        alert("Ingrese LineaNuevaBalcon");
        LineaNuevaBalcon.focus();
        return;
    }
    if (IncrementoBalcon.val() === "") {
        alert("Ingrese IncrementoBalcon");
        IncrementoBalcon.focus();
        return;
    }
    if (ProductoBalcon.val() === "") {
        alert("Ingrese ProductoBalcon");
        ProductoBalcon.focus();
        return;
    }
    if (Ult4DgtBalcon.val() === "") {
        alert("Ingrese Ult4DgtBalcon");
        Ult4DgtBalcon.focus();
        return;
    }
    if (TasaAnualBalcon.val() === "") {
        alert("Ingrese TasaAnualBalcon");
        TasaAnualBalcon.focus();
        return;
    }
    if (CatBalcon.val() === "") {
        alert("Ingrese CatBalcon");
        CatBalcon.focus();
        return;
    }
    if (FechaCatBalcon.val() === "") {
        alert("Ingrese FechaCatBalcon");
        FechaCatBalcon.focus();
        return;
    }
    if (MontoMaximoBalcon.val() === "") {
        alert("Ingrese MontoMaximoBalcon");
        MontoMaximoBalcon.focus();
        return;
    }
    if (TipoLlamadaBalcon.val() === "") {
        alert("Ingrese TipoLlamadaBalcon");
        TipoLlamadaBalcon.focus();
        return;
    }
    if (GepcBalcon.val() === "") {
        alert("Ingrese GepcBalcon");
        GepcBalcon.focus();
        return;
    }
    if (NombreBanco1Balcon.val() === "") {
        alert("Ingrese NombreBanco1Balcon");
        NombreBanco1Balcon.focus();
        return;
    }
    if (Plazo1Balcon.val() === "") {
        alert("Ingrese Plazo1Balcon");
        Plazo1Balcon.focus();
        return;
    }
    if (CantTransferencia1Balcon.val() === "") {
        alert("Ingrese CantTransferencia1Balcon");
        CantTransferencia1Balcon.focus();
        return;
    }
    if (Plazo2Balcon.val() === "") {
        alert("Ingrese Plazo2Balcon");
        Plazo2Balcon.focus();
        return;
    }
    if (NombreBanco2Balcon.val() === "") {
        alert("Ingrese NombreBanco2Balcon");
        NombreBanco2Balcon.focus();
        return;
    }
    if (CantTransferencia2Balcon.val() === "") {
        alert("Ingrese CantTransferencia2Balcon");
        CantTransferencia2Balcon.focus();
        return;
    }
    if (Plazo3Balcon.val() === "") {
        alert("Ingrese Plazo3Balcon");
        Plazo3Balcon.focus();
        return;
    }
    if (NombreBanco3Balcon.val() === "") {
        alert("Ingrese NombreBanco3Balcon");
        NombreBanco3Balcon.focus();
        return;
    }
    if (CantTransferencia3Balcon.val() === "") {
        alert("Ingrese CantTransferencia3Balcon");
        CantTransferencia3Balcon.focus();
        return;
    }
    if (Plazo4Balcon.val() === "") {
        alert("Ingrese Plazo4Balcon");
        Plazo4Balcon.focus();
        return;
    }
    if (NombreBanco4Balcon.val() === "") {
        alert("Ingrese NombreBanco4Balcon");
        NombreBanco4Balcon.focus();
        return;
    }
    if (CantTransferencia4Balcon.val() === "") {
        alert("Ingrese CantTransferencia4Balcon");
        CantTransferencia4Balcon.focus();
        return;
    }
    if (Plazo5Balcon.val() === "") {
        alert("Ingrese Plazo5Balcon");
        Plazo5Balcon.focus();
        return;
    }
    if (NombreBanco5Balcon.val() === "") {
        alert("Ingrese NombreBanco5Balcon");
        NombreBanco5Balcon.focus();
        return;
    }
    if (CantTransferencia5Balcon.val() === "") {
        alert("Ingrese CantTransferencia5Balcon");
        CantTransferencia5Balcon.focus();
        return;
    }
    if (EstatusBalcon.val() === "") {
        alert("Ingrese EstatusBalcon");
        EstatusBalcon.focus();
        return;
    }

    if (FechaVentaBalcon.val() === "") {
        alert("Ingrese fecha de venta");
        FechaVentaBalcon.focus();
        return;
    }

    if (FechaVicitaSucursalBN.val() === "") {
        alert("Ingrese fecha de visita");
        FechaVicitaSucursalBN.focus();
        return;
    }

    if (SucursalBN.val() === "") {
        alert("Ingrese plaza");
        SucursalBN.focus();
        return;
    }
    if (NumeroSucursalBN.val() === "") {
        alert("Agrega el piso");
        NumeroSucursalBN.focus();
        return;
    }
    if (RegionalBN.val() === "") {
        alert("Ingrese RegionalCPC");
        RegionalBN.focus();
        return;
    }
    if (DivisionBN.val() === "") {
        alert("Ingrese DivisionCPC");
        DivisionBN.focus();
        return;
    }

    var BalconEstatusVenta = "";
    if (UserType == 6) {//si es valdiador
        BalconEstatusVenta = $("#BalconEstatusVenta").val;
        if (BalconEstatusVenta == 0) {
            alert("Seleccione estatus de la venta");
            $("#BalconEstatusVenta").focus();
            return;
        }
    }

    var NumeroCliente = $("#Cliente");
    var Nombres = $("#Nombres");
    var ApellidoPaterno = $("#ApellidoPaterno");
    var ApellidoMaterno = $("#ApellidoMaterno");
    var FechaNacimiento = $("#FechaNacimiento");
    var RFC = $("#RFC");
    var Calle = $("#Calle");
    var NumeroExterior = $("#NumeroExterior");
    var NumeroInterior = $("#NumeroInterior");
    var CodigoPostal = $("#CodigoPostal");
    var Colonia = $("#Colonia");
    var Municipios = $("#Municipio");
    var Estados = $("#Estado");
    var Celular = $("#Celular");
    var TelefonoCasa = $("#TelefonoCasa");

    if (Nombres.val() === "") {
        alert("Debe ingresar nombre del cliente");
        Nombres.focus();
        return;
    }
    if (ApellidoPaterno.val() === "") {
        alert("Debe ingresar apellido paterno");
        ApellidoPaterno.focus();
        return;
    }
    if (ApellidoMaterno.val() === "") {
        alert("Debe ingresar apellido materno");
        ApellidoMaterno.focus();
        return;
    }
    if (FechaNacimiento.val() === "") {
        alert("Debe seleccionar fecha de nacimiento");
        FechaNacimiento.focus();
        return;
    }
    if (RFC.val() === "") {
        alert("Debe ingresarb un RFC");
        RFC.focus();
        return;
    }
    if (Calle.val() === "") {
        alert("Debe ingresar calle del cliente");
        Calle.focus();
        return;
    }
    if (NumeroExterior.val() === "") {
        alert("Ingrese numero exterior");
        NumeroExterior.focus();
        return;
    }
    if (NumeroInterior.val() === "") {
        alert("Ingrese numero interior");
        NumeroInterior.focus();
        return;
    }
    if (CodigoPostal.val() === "") {
        alert("Ingrese codigo postal");
        CodigoPostal.focus();
        return;
    }
    if (Estados.val() == 0) {
        alert("Seleccione un estado");
        Estados.focus();
        return;
    }
    if (Municipios.val() == 0) {
        alert("Seleccione un municipio");
        Municipios.focus();
        return;
    }
    if (Colonia.val() == 0) {
        alert("Ingrese Colonia");
        Colonia.focus();
        return;
    }

    var json = {
        Id: Id.val(),
        NumeroCliente: NumeroCliente.val(),
        Nombre: Nombres.val(),
        ApellidoPaterno: ApellidoPaterno.val(),
        ApellidoMaterno: ApellidoMaterno.val(),
        FechaNacimiento: FechaNacimiento.val(),
        RFC: RFC.val(),
        Calle: Calle.val(),
        NumeroExterior: NumeroExterior.val(),
        NumeroInterior: NumeroInterior.val(),
        CodigoPostal: CodigoPostal.val(),
        Colonia: Colonia.val(),
        Municipio: Municipios.val(),
        Estado: Estados.val(),
        Celular: Celular.val(),
        TelefonoCasa: TelefonoCasa.val(),

        Folio: FolioBalcon.val(),
        TelTrabajo: TelTrabajoBalcon.val(),
        Celular2: Celular2Balcon.val(),
        LineaActual: LineaActualBalcon.val(),
        LineaNueva: LineaNuevaBalcon.val(),
        Incremento: IncrementoBalcon.val(),
        Producto: ProductoBalcon.val(),
        Ult4DGT: Ult4DgtBalcon.val(),
        TasaAnual: TasaAnualBalcon.val(),
        Cat: CatBalcon.val(),
        FechaCat: FechaCatBalcon.val(),
        MontoMaximo: MontoMaximoBalcon.val(),
        TipoLlamada: TipoLlamadaBalcon.val(),
        Gepc: GepcBalcon.val(),
        Plazo1: Plazo1Balcon.val(),
        NombreBanco1: NombreBanco1Balcon.val(),
        CantTransferencia1: CantTransferencia1Balcon.val(),
        Plazo2: Plazo2Balcon.val(),
        NombreBanco2: NombreBanco2Balcon.val(),
        CantTransferencia2: CantTransferencia2Balcon.val(),
        Plazo3: Plazo3Balcon.val(),
        NombreBanco3: NombreBanco3Balcon.val(),
        CantTransferencia3: CantTransferencia3Balcon.val(),
        Plazo4: Plazo4Balcon.val(),
        NombreBanco4: NombreBanco4Balcon.val(),
        CantTransferencia4: CantTransferencia4Balcon.val(),
        Plazo5: Plazo5Balcon.val(),
        NombreBanco5: NombreBanco5Balcon.val(),
        CantTransferencia5: CantTransferencia5Balcon.val(),
        Estatus: EstatusBalcon.val(),
        FechaVenta: FechaVentaBalcon.val(),
        FechaVisitaSucursal: FechaVicitaSucursalBN.val(),
        Sucursal: SucursalBN.val(),
        NumeroSucursal: NumeroSucursalBN.val(),
        Division: DivisionBN.val(),
        Regional: RegionalBN.val()
    };
    saveBalconData(json);
    datos = json;
}

function saveBalconData(json) {
    showLoader();
    $.ajax({
        url: hostInit + '/Client/SaveBalconData',
        type: 'POST',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            //cambiar color
            noValidado("EstadoBalcon", "HeadingBalcon", "ValidarBalcon", "SaveBalcon");
            hideLoader();
            ValidarGrupo();
        },
        error: function (error) {
            console.log("Ocurrio un error al guardar los dao");
            hideLoader();
        }
    });
}


function FinloadBranchOfficeBalcon(mun, dia) {
    var json = {
        Valor: mun,
        Texto: dia
    }
    $.ajax({
        url: hostInit + '/Client/FinloadBranchOffice',
        type: 'POST',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            var tableContent = '';
            sucursalesCnc = new Array();
            if (dia == 1) {
                $("#headerTableSucursalCPC").append(
                    '<th id="colSabApCPC" class="small">SABADOS AP</th>' +
                    '<th id="colSabCieCPC" class="small">SABADOS CIE</th>'
                );
                for (var i in response) {
                    tableContent += '<tr>';
                    tableContent += '<td class="small"><a style="cursor: pointer" onclick="seleccionarSucBN(' + response[i].SIRH + ')">' + response[i].SIRH + '<a></td>';
                    tableContent += '<td class="small">' + response[i].NOMBRE_DISPOSITIVO + '</td>';
                    tableContent += '<td class="small">' + response[i].DIVISION + '</td>';
                    tableContent += '<td class="small">' + response[i].DIRECCION + '</td>';
                    tableContent += '<td class="small">' + response[i].DOMICILIO + '</td>';
                    tableContent += '<td class="small">' + response[i].COLONIA + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE1 + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE2 + '</td>';
                    tableContent += '<td class="small">' + response[i].DELEG_MUNIC + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_AP + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_CIE + '</td>';
                    tableContent += '<td class="small">' + response[i].SABADOS_AP + '</td>';
                    tableContent += '<td class="small">' + response[i].SABADOS_CIE + '</td>';
                    tableContent += '</tr>';
                    sucursalesCnc.push(response[i]);
                }
            } else {
                $("#colSabApCPC").remove();
                $("#colSabCieCPC").remove();
                for (var i in response) {
                    tableContent += '<tr>';
                    tableContent += '<td class="small"><a style="cursor: pointer" onclick="seleccionarSucBN(' + response[i].SIRH + ')">' + response[i].SIRH + '<a></td>';
                    tableContent += '<td class="small">' + response[i].NOMBRE_DISPOSITIVO + '</td>';
                    tableContent += '<td class="small">' + response[i].DIVISION + '</td>';
                    tableContent += '<td class="small">' + response[i].DIRECCION + '</td>';
                    tableContent += '<td class="small">' + response[i].DOMICILIO + '</td>';
                    tableContent += '<td class="small">' + response[i].COLONIA + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE1 + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE2 + '</td>';
                    tableContent += '<td class="small">' + response[i].DELEG_MUNIC + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_AP + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_CIE + '</td>';
                    tableContent += '</tr>';
                    sucursalesCnc.push(response[i]);
                }
            }

            $("#bodyTableSucCPC").html(tableContent);
            $('#myModalSucursalesCPC').modal('show');
        },
        error: function (reject) {
            console.log(reject);
        }
    });
}


function seleccionarSucBN(SIRH) {
    for (var i in sucursalesCnc) {
        if (sucursalesCnc[i].SIRH == SIRH) {
            $("#DivisionBN").val(sucursalesCnc[i].DIVISION);
            $("#RegionalBN").val(sucursalesCnc[i].DIRECCION);
            $("#NumeroSucursalBN").val(sucursalesCnc[i].SIRH);
            $("#SucursalBN").val(sucursalesCnc[i].NOMBRE_DISPOSITIVO);
            break;
        }
    }
    $('#myModalSucursalesCPC').modal('hide');
}


