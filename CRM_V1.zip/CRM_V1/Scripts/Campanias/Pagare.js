﻿var datos;
function SetPagareData(FolioPagare, id, CuentaBasicaPagare, CuentaBasicaCFCPagare, CuentaCPCPagare, CuentaEjePagare,
    CuentaEjeCFCPagare, DescuentoOfertaPagare, FechaCatPagare, GerenciaDeMercadoPagare,
    NMSucursalPagare, NombreEmpresaPagare, NumeroContratoPagare, PrioridadPagare,
    RangoLineaPagare, SubOfertaPagare, Tasa1Pagare, Tasa2Pagare, Telefono1Pagare,
    TelefonoOficina1Pagare, TelefonoOficina2Pagare, TipoBasePagare, Celular1Pagare, Celular2Pagare, EmailPagare,
    FechaVicitaSucursal, DivisionPagare, RegionalDivision, NumeroSucursalPagare) {
    $("#IdPagare").val(id);
    $("#CuentaBasicaPagare").val(CuentaBasicaPagare);
    $("#CuentaBasicaCFCPagare").val(CuentaBasicaCFCPagare);
    $("#CuentaCPCPagare").val(CuentaCPCPagare);
    $("#CuentaEjePagare").val(CuentaEjePagare);
    $("#CuentaEjeCFCPagare").val(CuentaEjeCFCPagare);
    $("#DescuentoOfertaPagare").val(DescuentoOfertaPagare);
    $("#FechaCatPagare").val(formatDate(FechaCatPagare));

    $("#FolioPagare").val(FolioPagare);
    $("#GerenciaDeMercadoPagare").val(GerenciaDeMercadoPagare);
    $("#NMSucursalPagare").val(NMSucursalPagare);
    $("#NombreEmpresaPagare").val(NombreEmpresaPagare);
    $("#NumeroContratoPagare").val(NumeroContratoPagare);
    $("#PrioridadPagare").val(PrioridadPagare);
    $("#RangoLineaPagare").val(RangoLineaPagare);
    $("#SubOfertaPagare").val(SubOfertaPagare);
    $("#Tasa1Pagare").val(Tasa1Pagare);
    $("#Tasa2Pagare").val(Tasa2Pagare);
    $("#Telefono1Pagare").val(Telefono1Pagare);
    $("#TelefonoOficina1Pagare").val(TelefonoOficina1Pagare);
    $("#TelefonoOficina2Pagare").val(TelefonoOficina2Pagare);
    $("#TipoBasePagare").val(TipoBasePagare);
    $("#Celular1Pagare").val(Celular1Pagare);
    $("#Celular2Pagare").val(Celular2Pagare);
    $("#EmailPagare").val(EmailPagare);

    $("#DivisionPagare").val(DivisionPagare);
    $("#RegionalPagare").val(RegionalDivision);
    $("#NumeroSucursalPagare").val(NumeroSucursalPagare);
    $("#StatusSalePagare").html(ComboCatalogo());
    document.getElementById("SavePagare").onclick = function () {
        ValidatePagareData();
    }

    document.getElementById("ValidatePagare").onclick = function () {
        ValidarVentaPagare();
    }

    document.getElementById('DetalleSucursalPAGARE').addEventListener('click', function () {
        LoadDetailsOffice(document.getElementById('NumeroSucursalPagare').value);
    });

    $("#FechaCatPagare").datepicker(dataCalendar);
    var cal = dataCalendar;
		if (datos === undefined)
	{
	}
	else 	
	{
		delete datos;
	}
    switch (EstatusVenta) {
        case -1://no se ha tocado
        case 2://no venta
            var currentDate = new Date();
            cal['beforeShowDay'] = function (day) {
                var day = day.getDay();
                if (day == 0) {
                    return [false, "somecssclass"]
                }
                return [true, "someothercssclass"]
            }
            var fexhMas = '+' + sumaDias(currentDate) + 'D';
            cal['minDate'] = '+0D';
            cal['maxDate'] = fexhMas;
            $("#FechaVicitaSucursalPagare").datepicker(cal);
            var day = currentDate.getDate();
            var monthIndex = currentDate.getMonth();
            var year = currentDate.getFullYear();

            var fecha = year + "/" + (monthIndex + 1) + "/" + day;
            $("#FechaVicitaSucursalPagare").val(fecha);
            noVendido("EstadoPagare", "HeadingPagare", "ValidarPagare", "SavePagare");
            setFieldsPagare("");
            break;
        case 0://ya se vendio, no se ha validado
            $("#FechaVicitaSucursalPagare").val(formatDate(FechaVicitaSucursal));
            $("#FechaVicitaSucursalPagare").datepicker(cal);
            noValidado("EstadoPagare", "HeadingPagare", "ValidarPagare", "SavePagare");

            var NumeroCliente = $("#Cliente");
            var Nombres = $("#Nombres");
            var ApellidoPaterno = $("#ApellidoPaterno");
            var ApellidoMaterno = $("#ApellidoMaterno");
            var FechaNacimiento = $("#FechaNacimiento");
            var RFC = $("#RFC");
            var Calle = $("#Calle");
            var NumeroExterior = $("#NumeroExterior");
            var NumeroInterior = $("#NumeroInterior");
            var CodigoPostal = $("#CodigoPostal");
            var Colonia = $("#Colonia");
            var Municipios = $("#Municipio");
            var Estados = $("#Estado");
            var Celular = $("#Celular");
            var TelefonoCasa = $("#TelefonoCasa");

            var Id = $("#IdPagare");
            var CuentaBasicaPagare = $("#CuentaBasicaPagare");
            var CuentaBasicaCFCPagare = $("#CuentaBasicaCFCPagare");
            var CuentaCPCPagare = $("#CuentaCPCPagare");
            var CuentaEjePagare = $("#CuentaEjePagare");
            var CuentaEjeCFCPagare = $("#CuentaEjeCFCPagare");
            var DescuentoOfertaPagare = $("#DescuentoOfertaPagare");
            var FechaCatPagare = $("#FechaCatPagare");
            var FolioPagare = $("#FolioPagare");
            var GerenciaDeMercadoPagare = $("#GerenciaDeMercadoPagare");
            var NMSucursalPagare = $("#NMSucursalPagare");
            var NombreEmpresaPagare = $("#NombreEmpresaPagare");
            var NumeroContratoPagare = $("#NumeroContratoPagare");
            var PrioridadPagare = $("#PrioridadPagare");
            var RangoLineaPagare = $("#RangoLineaPagare");
            var SubOfertaPagare = $("#SubOfertaPagare");
            var Tasa1Pagare = $("#Tasa1Pagare");
            var Tasa2Pagare = $("#Tasa2Pagare");
            var Telefono1Pagare = $("#Telefono1Pagare");
            var TelefonoOficina1Pagare = $("#TelefonoOficina1Pagare");
            var TelefonoOficina2Pagare = $("#TelefonoOficina2Pagare");
            var TipoBasePagare = $("#TipoBasePagare");
            var Celular1Pagare = $("#Celular1Pagare");
            var Celular2Pagare = $("#Celular2Pagare");
            var EmailPagare = $("#EmailPagare");
            var FechaVicitaSucursalPagare = $("#FechaVicitaSucursalPagare");
            var DivisionPagare = $("#DivisionPagare");
            var RegionalDivision = $("#RegionalPagare");
            var NumeroSucursalPagare = $("#NumeroSucursalPagare");

            datos = {
                Id: Id.val(),
                NumeroCliente: NumeroCliente.val(),
                Nombre: Nombres.val(),
                ApellidoPaterno: ApellidoPaterno.val(),
                ApellidoMaterno: ApellidoMaterno.val(),
                FechaNacimiento: FechaNacimiento.val(),
                RFC: RFC.val(),
                Calle: Calle.val(),
                NumeroExterior: NumeroExterior.val(),
                NumeroInterior: NumeroInterior.val(),
                CodigoPostal: CodigoPostal.val(),
                Colonia: Colonia.val(),
                Municipio: Municipios.val(),
                Estado: Estados.val(),
                Celular: Celular.val(),
                TelefonoCasa: TelefonoCasa.val(),

                CuentaBasica: CuentaBasicaPagare.val(),
                CuentaBasicaCFC: CuentaBasicaCFCPagare.val(),
                CuentaCPC: CuentaCPCPagare.val(),
                CuentaEje: CuentaEjePagare.val(),
                CuentaEjeCFC: CuentaEjeCFCPagare.val(),
                DescuentoOferta: DescuentoOfertaPagare.val(),
                FechaCat: FechaCatPagare.val(),
                Folio: FolioPagare.val(),
                GerenciaDeMercado: GerenciaDeMercadoPagare.val(),
                Sucursal: NMSucursalPagare.val(),
                NombreEmpresa: NombreEmpresaPagare.val(),
                NumeroContrato: NumeroContratoPagare.val(),
                Prioridad: PrioridadPagare.val(),
                RangoLinea: RangoLineaPagare.val(),
                SubOferta: SubOfertaPagare.val(),
                Tasa1: Tasa1Pagare.val(),
                Tasa2: Tasa2Pagare.val(),
                Telefono1: Telefono1Pagare.val(),
                TelefonoOficina1: TelefonoOficina1Pagare.val(),
                TelefonoOficina2: TelefonoOficina2Pagare.val(),
                TipoBase: TipoBasePagare.val(),
                Celular1: Celular1Pagare.val(),
                Celular2: Celular2Pagare.val(),
                Email: EmailPagare.val(),
                FechaVicitaSucursal: FechaVicitaSucursalPagare.val(),
                EstatusVenta: PagareEstatusVenta,
                Division: DivisionPagare.val(),
                Regional: RegionalDivision.val(),
                NumeroSucursal: NumeroSucursalPagare.val(),
                EstatusVenta: EstatusVenta
            };
            break;
        case 1://venta exitosa
            $("#FechaVicitaSucursalPagare").val(formatDate(FechaVicitaSucursal));
            ventaExitosa("EstadoPagare", "HeadingPagare", "ValidarPagare", "SavePagare");
            setFieldsPagare("enabled");
            break;
    }

    document.getElementById("OpenScriptPagare").onclick = function () {
        window.open(hostInit + '/Client/OpenPdf/PAGARE', '_blank', 'location=no, resizable=no', true);
    }
}

function ValidarVentaPagare() {
    var UserName = $("#UserPagare");
    var Password = $("#PasswordPagare");

    if (UserName.val() === "") {
        UserName.focus();
        return;
    }
    if (Password.val() === "") {
        Password.focus();
        return;
    }
    var json = {
        UserName: UserName.val(),
        Password: Password.val()
    };
    var itemSelect = document.getElementById("StatusSalePagare");
    if (itemSelect.options[itemSelect.selectedIndex].value == 0) {
        alert("Debe seleccionar un estado de la venta al validar");
        return;
    }
    showLoader();
    $.ajax({
        url: hostInit + "/User/LogIn",
        type: 'POST',
        crossDomain: 'true',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            if (response === "No existe") {
                alert("Usuario o contraseña incorrecto(s)");
                UserName.val("");
                Password.val("");
                UserName.focus();
                hideLoader();
                return;
            }
            if (response['Tipo'] == 6) {
                datos['EstatusVenta'] = $("#StatusSalePagare").val();
                $.ajax({
                    url: hostInit + '/Client/SavePagareData',
                    type: 'POST',
                    contentType: 'application/json;charset=utf-8',
                    data: JSON.stringify(datos),
                    success: function (response) {
                        if (datos['EstatusVenta'] == 2) {//no venta
                            noVendido("EstadoPagare", "HeadingPagare", "ValidarPagare", "SavePagare");
                        } else {
                            ventaExitosa("EstadoPagare", "HeadingPagare", "ValidarPagare", "SavePagare");
                            setFieldsPagare("disabled");
                            $("#collapse11").collapse('hide');
                        }
                        $("#StatusSalePagare").val(0);
                        hideLoader();
                    },
                    error: function (error) {
                        console.log("Ocurrio un error al guardar los dao");
                        hideLoader();
                    }
                });
            } else {
                alert("No tiene los privilegios de validador");
                hideLoader();
            }
            UserName.val("");
            Password.val("");
        },
        error: function (error) {
            alert("error al entrar como validador");
            hideLoader();
        }
    });
}

function setFieldsPagare(value) {
    $("#CuentaBasicaPagare").prop("disabled", value);
    $("#CuentaBasicaCFCPagare").prop("disabled", value);
    $("#CuentaCPCPagare").prop("disabled", value);
    $("#CuentaEjePagare").prop("disabled", value);
    $("#CuentaEjeCFCPagare").prop("disabled", value);
    $("#DescuentoOfertaPagare").prop("disabled", value);
    $("#FechaCatPagare").prop("disabled", value);
    $("#GerenciaDeMercadoPagare").prop("disabled", value);
    $("#NMSucursalPagare").prop("disabled", value);
    $("#NumeroSucursalPagare").prop("disabled", value);
    $("#NombreEmpresaPagare").prop("disabled", value);
    $("#NumeroContratoPagare").prop("disabled", value);
    $("#PrioridadPagare").prop("disabled", value);
    $("#RangoLineaPagare").prop("disabled", value);
    $("#SubOfertaPagare").prop("disabled", value);
    $("#Tasa1Pagare").prop("disabled", value);
    $("#Tasa2Pagare").prop("disabled", value);
    $("#Telefono1Pagare").prop("disabled", value);
    $("#TelefonoOficina1Pagare").prop("disabled", value);
    $("#TelefonoOficina2Pagare").prop("disabled", value);
    $("#TipoBasePagare").prop("disabled", value);
    $("#Celular1Pagare").prop("disabled", value);
    $("#Celular2Pagare").prop("disabled", value);
    $("#EmailPagare").prop("disabled", value);
    $("#FechaVicitaSucursalPagare").prop("disabled", value);
    $("#DivisionPagare").prop("disabled", value);
    $("#RegionalPagare").prop("disabled", value);
}

function ValidatePagareData() {
    var Id = $("#IdPagare");
    var CuentaBasicaPagare = $("#CuentaBasicaPagare");
    var CuentaBasicaCFCPagare = $("#CuentaBasicaCFCPagare");
    var CuentaCPCPagare = $("#CuentaCPCPagare");
    var CuentaEjePagare = $("#CuentaEjePagare");
    var CuentaEjeCFCPagare = $("#CuentaEjeCFCPagare");
    var DescuentoOfertaPagare = $("#DescuentoOfertaPagare");
    var FechaCatPagare = $("#FechaCatPagare");
    var FolioPagare = $("#FolioPagare");
    var GerenciaDeMercadoPagare = $("#GerenciaDeMercadoPagare");
    var NMSucursalPagare = $("#NMSucursalPagare");
    var NombreEmpresaPagare = $("#NombreEmpresaPagare");
    var NumeroContratoPagare = $("#NumeroContratoPagare");
    var PrioridadPagare = $("#PrioridadPagare");
    var RangoLineaPagare = $("#RangoLineaPagare");
    var SubOfertaPagare = $("#SubOfertaPagare");
    var Tasa1Pagare = $("#Tasa1Pagare");
    var Tasa2Pagare = $("#Tasa2Pagare");
    var Telefono1Pagare = $("#Telefono1Pagare");
    var TelefonoOficina1Pagare = $("#TelefonoOficina1Pagare");
    var TelefonoOficina2Pagare = $("#TelefonoOficina2Pagare");
    var TipoBasePagare = $("#TipoBasePagare");
    var Celular1Pagare = $("#Celular1Pagare");
    var Celular2Pagare = $("#Celular2Pagare");
    var EmailPagare = $("#EmailPagare");
    var FechaVicitaSucursalPagare = $("#FechaVicitaSucursalPagare");
    var DivisionPagare = $("#DivisionPagare");
    var RegionalDivision = $("#RegionalPagare");
    var NumeroSucursalPagare = $("#NumeroSucursalPagare");
    if (CuentaBasicaPagare.val() === "") {
        alert("Debe ingresar CuentaBasicaPagare");
        CuentaBasicaPagare.focus();
        return;
    }
    if (CuentaBasicaCFCPagare.val() === "") {
        alert("Debe ingresar el folio del producto");
        CuentaBasicaCFCPagare.focus();
        return;
    }
    if (CuentaCPCPagare.val() === "") {
        alert("Debe ingresar la fecha 1");
        CuentaCPCPagare.focus();
        return;
    }
    if (CuentaEjePagare.val() === "") {
        alert("Ingrese producto");
        CuentaEjePagare.focus();
        return;
    }
    if (CuentaEjeCFCPagare.val() === "") {
        alert("Debe ingresar linea actual");
        CuentaEjeCFCPagare.focus();
        return;
    }
    if (DescuentoOfertaPagare.val() === "") {
        alert("Debe ingresar liena incremento");
        DescuentoOfertaPagare.focus();
        return;
    }
    if (FechaCatPagare.val() === "") {
        alert("Debe ingresar producto 2");
        FechaCatPagare.focus();
        return;
    }
    if (FolioPagare.val() === "") {
        alert("Ingrese producto 3");
        FolioPagare.focus();
        return;
    }
    if (GerenciaDeMercadoPagare.val() === "") {
        alert("Ingrese linea F");
        GerenciaDeMercadoPagare.focus();
        return;
    }
    if (NMSucursalPagare.val() === "") {
        alert("Ingrese linea TDC");
        NMSucursalPagare.focus();
        return;
    }

    if (NombreEmpresaPagare.val() === "") {
        alert("Ingrese RFC RVT");
        NombreEmpresaPagare.focus();
        return;
    }
    if (NumeroContratoPagare.val() === "") {
        alert("Ingrese plaza");
        NumeroContratoPagare.focus();
        return;
    }
    if (PrioridadPagare.val() === "") {
        alert("Agrega el piso");
        PrioridadPagare.focus();
        return;
    }
    if (RangoLineaPagare.val() === "") {
        alert("Ingrese cliente desde");
        RangoLineaPagare.focus();
        return;
    }

    if (SubOfertaPagare.val() === "") {
        alert("Ingrese plaza");
        SubOfertaPagare.focus();
        return;
    }
    if (Tasa1Pagare.val() === "") {
        alert("Agrega el piso");
        Tasa1Pagare.focus();
        return;
    }
    if (Tasa2Pagare.val() === "") {
        alert("Ingrese cliente desde");
        Tasa2Pagare.focus();
        return;
    }

    if (Telefono1Pagare.val() === "") {
        alert("Ingrese RFC RVT");
        Telefono1Pagare.focus();
        return;
    }
    if (TelefonoOficina1Pagare.val() === "") {
        alert("Ingrese plaza");
        TelefonoOficina1Pagare.focus();
        return;
    }
    if (TelefonoOficina2Pagare.val() === "") {
        alert("Agrega el piso");
        TelefonoOficina2Pagare.focus();
        return;
    }
    if (TipoBasePagare.val() === "") {
        alert("Ingrese cliente desde");
        TipoBasePagare.focus();
        return;
    }

    if (Celular1Pagare.val() === "") {
        alert("Ingrese plaza");
        Celular1Pagare.focus();
        return;
    }
    if (Celular2Pagare.val() === "") {
        alert("Agrega el piso");
        Celular2Pagare.focus();
        return;
    }
    if (EmailPagare.val() === "") {
        alert("Ingrese cliente desde");
        EmailPagare.focus();
        return;
    }
    if (FechaVicitaSucursalPagare.val() === "") {
        alert("Seleccione FechaVicitaSucursalPagare");
        FechaVicitaSucursalPagare.focus();
        return;
    }
    if (DivisionPagare.val() === "") {
        alert("Ingrese DivisionPagare");
        DivisionPagare.focus();
        return;
    }
    if (RegionalDivision.val() === "") {
        alert("Ingrese RegionalDivision");
        RegionalDivision.focus();
        return;
    }
    if (NumeroSucursalPagare.val() === "") {
        alert("Ingrese NumeroSucursalPagare");
        NumeroSucursalPagare.focus();
        return;
    }
    var PagareEstatusVenta = "";
    if (UserType == 6) {//si es valdiador
        PagareEstatusVenta = $("#PagareEstatusVenta").val();
        if (PagareEstatusVenta == 0) {
            alert("Seleccione estatus de la venta");
            $("#PagareEstatusVenta").focus();
            return;
        }
    }

    var NumeroCliente = $("#Cliente");
    var Nombres = $("#Nombres");
    var ApellidoPaterno = $("#ApellidoPaterno");
    var ApellidoMaterno = $("#ApellidoMaterno");
    var FechaNacimiento = $("#FechaNacimiento");
    var RFC = $("#RFC");
    var Calle = $("#Calle");
    var NumeroExterior = $("#NumeroExterior");
    var NumeroInterior = $("#NumeroInterior");
    var CodigoPostal = $("#CodigoPostal");
    var Colonia = $("#Colonia");
    var Municipios = $("#Municipio");
    var Estados = $("#Estado");
    var Celular = $("#Celular");
    var TelefonoCasa = $("#TelefonoCasa");


    if (Nombres.val() === "") {
        alert("Debe ingresar nombre del cliente");
        Nombres.focus();
        return;
    }
    if (ApellidoPaterno.val() === "") {
        alert("Debe ingresar apellido paterno");
        ApellidoPaterno.focus();
        return;
    }
    if (ApellidoMaterno.val() === "") {
        alert("Debe ingresar apellido materno");
        ApellidoMaterno.focus();
        return;
    }
    if (FechaNacimiento.val() === "") {
        alert("Debe seleccionar fecha de nacimiento");
        FechaNacimiento.focus();
        return;
    }
    if (RFC.val() === "") {
        alert("Debe ingresarb un RFC");
        RFC.focus();
        return;
    }
    if (Calle.val() === "") {
        alert("Debe ingresar calle del cliente");
        Calle.focus();
        return;
    }
    if (NumeroExterior.val() === "") {
        alert("Ingrese numero exterior");
        NumeroExterior.focus();
        return;
    }
    if (NumeroInterior.val() === "") {
        alert("Ingrese numero interior");
        NumeroInterior.focus();
        return;
    }
    if (CodigoPostal.val() === "") {
        alert("Ingrese codigo postal");
        CodigoPostal.focus();
        return;
    }
    if (Estados.val() == 0) {
        alert("Seleccione un estado");
        Estados.focus();
        return;
    }
    if (Municipios.val() == 0) {
        alert("Seleccione un municipio");
        Municipios.focus();
        return;
    }
    if (Colonia.val() == 0) {
        alert("Ingrese Colonia");
        Colonia.focus();
        return;
    }

    var json = {
        Id: Id.val(),
        NumeroCliente: NumeroCliente.val(),
        Nombre: Nombres.val(),
        ApellidoPaterno: ApellidoPaterno.val(),
        ApellidoMaterno: ApellidoMaterno.val(),
        FechaNacimiento: FechaNacimiento.val(),
        RFC: RFC.val(),
        Calle: Calle.val(),
        NumeroExterior: NumeroExterior.val(),
        NumeroInterior: NumeroInterior.val(),
        CodigoPostal: CodigoPostal.val(),
        Colonia: Colonia.val(),
        Municipio: Municipios.val(),
        Estado: Estados.val(),
        Celular: Celular.val(),
        TelefonoCasa: TelefonoCasa.val(),

        CuentaBasica: CuentaBasicaPagare.val(),
        CuentaBasicaCFC: CuentaBasicaCFCPagare.val(),
        CuentaCPC: CuentaCPCPagare.val(),
        CuentaEje: CuentaEjePagare.val(),
        CuentaEjeCFC: CuentaEjeCFCPagare.val(),
        DescuentoOferta: DescuentoOfertaPagare.val(),
        FechaCat: FechaCatPagare.val(),
        Folio: FolioPagare.val(),
        GerenciaDeMercado: GerenciaDeMercadoPagare.val(),
        Sucursal: NMSucursalPagare.val(),
        NombreEmpresa: NombreEmpresaPagare.val(),
        NumeroContrato: NumeroContratoPagare.val(),
        Prioridad: PrioridadPagare.val(),
        RangoLinea: RangoLineaPagare.val(),
        SubOferta: SubOfertaPagare.val(),
        Tasa1: Tasa1Pagare.val(),
        Tasa2: Tasa2Pagare.val(),
        Telefono1: Telefono1Pagare.val(),
        TelefonoOficina1: TelefonoOficina1Pagare.val(),
        TelefonoOficina2: TelefonoOficina2Pagare.val(),
        TipoBase: TipoBasePagare.val(),
        Celular1: Celular1Pagare.val(),
        Celular2: Celular2Pagare.val(),
        Email: EmailPagare.val(),
        FechaVicitaSucursal: FechaVicitaSucursalPagare.val(),
        EstatusVenta: PagareEstatusVenta,
        Division: DivisionPagare.val(),
        Regional: RegionalDivision.val(),
        NumeroSucursal: NumeroSucursalPagare.val()
    };
    datos = json;
    savePagareData(json);
}


function savePagareData(json) {
    showLoader();
    $.ajax({
        url: hostInit + '/Client/SavePagareData',
        type: 'POST',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            noValidado("EstadoPagare", "HeadingPagare", "ValidarPagare", "SavePagare");
            hideLoader();

        },
        error: function (error) {
            console.log("Ocurrio un error al guardar los dao");
            hideLoader();
        }
    });
}
