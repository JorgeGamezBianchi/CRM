﻿var datos;
function SetCpcData(id, FolioCPC, MontoMaximo24CPC, Pago24CPC,
    MontoMaximo36CPC, Pago36CPC, MontoMaximo48CPC, Pago48CPC,
    MontoMaximo60CPC, Pago60CPC, TasaCPC, PlazoCPC, MontoPromesaCPC,
    FechaVicitaSucursalCPC, SucursalCPC, NumeroSucursalCPC,
    RegionalCPC, DivisionCPC, EstatusVenta, EstadoSucursal, MunicipioSucursal,
    OfertaCPC, CAT
) {
    $("#IdCpc").val(id);
    $("#FolioCPC").val(FolioCPC);
    $("#MontoMaximo24CPC").val(MontoMaximo24CPC);
    $("#Pago24CPC").val(Pago24CPC);
    $("#MontoMaximo36CPC").val(MontoMaximo36CPC);
    $("#Pago36CPC").val(Pago36CPC);
    $("#MontoMaximo48CPC").val(MontoMaximo48CPC);
    $("#Pago48CPC").val(Pago48CPC);

    //(1) Mantenimiento 04 marzo 2019
    $("#MontoMaximo60CPC").val(MontoMaximo60CPC);
    $("#Pago60CPC").val(Pago60CPC);

    $("#TasaCPC").val(TasaCPC);
    $("#PlazoCPC").val(PlazoCPC);
    $("#MontoPromesaCPC").val(MontoPromesaCPC);
    $("#SucursalCPC").val(SucursalCPC);
    $("#NumeroSucursalCPC").val(NumeroSucursalCPC);
    $("#RegionalCPC").val(RegionalCPC);

    $("#DivisionCPC").val(DivisionCPC);
    document.getElementById("selectVenta").value = "Seleccione...";


    //(1) Mantenimiento 15 marzo 2019
    $("#OfertaCPC").val(OfertaCPC);
    $("#CAT").val(CAT);
    
    //cargar estados para las sucursales cnc
    estados("EstadoSucursalCPC", EstadoSucursal, 0);
    LoadMunicipios(EstadoSucursal, MunicipioSucursal, 'MunicipioSucursalCPC');
    $("#EstadoSucursalCPC").change(function (evt) {
        var item = $(this).val();
        LoadMunicipios(item, 0, 'MunicipioSucursalCPC');
    });

    $("#MunicipioSucursalCPC").change(function (evt) {
        var item = $(this).val();
        var fechVicSuc = $("#FechaVicitaSucursalCPC").val();
        if (fechVicSuc === "") {
            alert("Seleccione fecha vicita sucursal");
            $("#FechaVicitaSucursalCPC").focus();
            return;
        }

        if (item === "0") {
            alert("Seleccione un municipio");
            $("#MunicipioSucursalCPC").focus();
            return;
        }

        var dia = diaSemana(fechVicSuc);
        if (dia === 'sab') {
            FinloadBranchOfficeCPC(item, 1);
        } else {
            FinloadBranchOfficeCPC(item, 0);
        }
    })

    $("#StatusSaleCpc").html(ComboCatalogo());
    document.getElementById("SaveCpc").onclick = function () {
        ValidateCpcData();
    };

    document.getElementById("ValidateCpc").onclick = function () {
        ValidarCpc();
    }

    document.getElementById("DetalleSucursalCPC").addEventListener('click', function () {
        LoadDetailsOffice(document.getElementById('NumeroSucursalCPC').value);
    });

    var cal = dataCalendar;
		if (datos === undefined)
	{
	}
	else 	
	{
		delete datos;
	}
    switch (EstatusVenta) {
        case -1://no se ha tocado
        case 2://no venta
            var currentDate = new Date();
            cal['beforeShowDay'] = function (day) {
                var day = day.getDay();
                if (day == 0) {
                    return [false, "somecssclass"]
                }
                return [true, "someothercssclass"]
            }
            var fexhMas = '+' + sumaDias(currentDate) + 'D';
            cal['minDate'] = '+0D';
            cal['maxDate'] = fexhMas;
            var day = currentDate.getDate();
            var monthIndex = currentDate.getMonth();
            var year = currentDate.getFullYear();
            var fecha = year + "/" + (monthIndex + 1) + "/" + day;

            $("#FechaVicitaSucursalCPC").datepicker(cal);
            $("#FechaVicitaSucursalCPC").val(fecha);
            noVendido("EstadoCpc", "HeadingCpc", "ValidarCpc", "SaveCpc");
            setFieldsCpc("");
            break;
        case 0://ya se vendio, no se ha validado
            $("#FechaVicitaSucursalCPC").val(formatDate(FechaVicitaSucursalCPC));
            $("#FechaVicitaSucursalCPC").datepicker(cal);
            noValidado("EstadoCpc", "HeadingCpc", "ValidarCpc", "SaveCpc");

            var Id = $("#IdCpc");
            var FolioCPC = $("#FolioCPC");

            //(1) Mantenimiento 04 marzo 2019
            var MontoMaximo60CPC = $("#MontoMaximo60CPC");
            var Pago60CPC = $("#Pago60CPC");

            var MontoMaximo24CPC = $("#MontoMaximo24CPC");
            var Pago24CPC = $("#Pago24CPC");
            var MontoMaximo36CPC = $("#MontoMaximo36CPC");
            var Pago36CPC = $("#Pago36CPC");
            var MontoMaximo48CPC = $("#MontoMaximo48CPC");
            var Pago48CPC = $("#Pago48CPC");
            var TasaCPC = $("#TasaCPC");
            var PlazoCPC = $("#PlazoCPC");
            var MontoPromesaCPC = $("#MontoPromesaCPC");
            var FechaVicitaSucursalCPC = $("#FechaVicitaSucursalCPC");
            var SucursalCPC = $("#SucursalCPC");
            var NumeroSucursalCPC = $("#NumeroSucursalCPC");
            var RegionalCPC = $("#RegionalCPC");

            var DivisionCPC = $("#DivisionCPC");
            //(1) Mantenimiento 15 marzo 2019
            var OfertaCPC = $("#OfertaCPC");

            var NumeroCliente = $("#Cliente");
            var Nombres = $("#Nombres");
            var ApellidoPaterno = $("#ApellidoPaterno");
            var ApellidoMaterno = $("#ApellidoMaterno");
            var FechaNacimiento = $("#FechaNacimiento");
            var RFC = $("#RFC");
            var Calle = $("#Calle");
            var NumeroExterior = $("#NumeroExterior");
            var NumeroInterior = $("#NumeroInterior");
            var CodigoPostal = $("#CodigoPostal");
            var Colonia = $("#Colonia");
            var Municipios = $("#Municipio");
            var Estados = $("#Estado");
            var Celular = $("#Celular");
            var TelefonoCasa = $("#TelefonoCasa");

            //(1) Mantenimiento 04 marzo 2019
            //Mantenimiento 15 marzo 2019 Oferta: OfertaCPC.val(),
            datos = {
                Id: Id.val(),
                NumeroCliente: NumeroCliente.val(),
                Nombre: Nombres.val(),
                ApellidoPaterno: ApellidoPaterno.val(),
                ApellidoMaterno: ApellidoMaterno.val(),
                FechaNacimiento: FechaNacimiento.val(),
                RFC: RFC.val(),
                Calle: Calle.val(),
                NumeroExterior: NumeroExterior.val(),
                NumeroInterior: NumeroInterior.val(),
                CodigoPostal: CodigoPostal.val(),
                Colonia: Colonia.val(),
                Municipio: Municipios.val(),
                Estado: Estados.val(),
                Celular: Celular.val(),
                TelefonoCasa: TelefonoCasa.val(),
                Folio: FolioCPC.val(),
                MontoMax24: MontoMaximo24CPC.val(),
                Pago24: Pago24CPC.val(),
                MontoMax36: MontoMaximo36CPC.val(),
                Pago36: Pago36CPC.val(),
                MontoMax48: MontoMaximo48CPC.val(),
                Pago48: Pago48CPC.val(),
                MontoMax12: MontoMaximo60CPC.val(),
                Pago12: Pago60CPC.val(),
                Tasa: TasaCPC.val(),
                Plazo: PlazoCPC.val(),
                MontoPromesa: MontoPromesaCPC.val(),
                FechaVicitaSucursal: FechaVicitaSucursalCPC.val(),
                Sucursal: SucursalCPC.val(),
                NumeroSucursal: NumeroSucursalCPC.val(),

                Division: DivisionCPC.val(),
                Oferta: OfertaCPC.val(),

                Regional: RegionalCPC.val(),
                EstatusVenta: EstatusVenta
            };

            break;
        case 1://venta exitosa
            $("#FechaVicitaSucursalCPC").val(formatDate(FechaVicitaSucursalCPC));
            ventaExitosa("EstadoCpc", "HeadingCpc", "ValidarCpc", "SaveCpc");
            setFieldsCpc("enabled");
            break;
    }

    document.getElementById("OpenScriptCpc").onclick = function () {
        window.open(hostInit + '/Client/OpenPdf/CPC', '_blank', 'location=no, resizable=no', true);
    }
    ValidarGrupo();
}

function setFieldsCpc(value) {
    //$("#MontoMaximo24CPC").prop("disabled", value);
    //$("#Pago24CPC").prop("disabled", value);
    //$("#MontoMaximo36CPC").prop("disabled", value);
    //$("#Pago36CPC").prop("disabled", value);
    //$("#MontoMaximo48CPC").prop("disabled", value);
    //$("#Pago48CPC").prop("disabled", value);

    //(1) Mantenimiento 04 marzo 2019
    //$("#MontoMaximo60CPC").prop("disabled", value);
    //$("#Pago60CPC").prop("disabled", value);

    //$("#TasaCPC").prop("disabled", value);
    //$("#PlazoCPC").prop("disabled", value);
    //$("#MontoPromesaCPC").prop("disabled", value);
    $("#FechaVicitaSucursalCPC").prop("disabled", value);
    $("#SucursalCPC").prop("disabled", value);
    $("#NumeroSucursalCPC").prop("disabled", value);
    $("#RegionalCPC").prop("disabled", value);

    $("#DivisionCPC").prop("disabled", value);
    $("#OfertaCPC").prop("disabled", value);

    $("#EstadoSucursalCpc").prop("disabled", value);
    $("#MunicipioSucursalCpc").prop("disabled", value);
}

//Mantenimiento 15 marzo 2019 Oferta: OfertaCPC.val(),
function ValidateCpcData() {

    var Id = $("#IdCpc");
    var FolioCPC = $("#FolioCPC");
    var MontoMaximo60CPC = $("#MontoMaximo60CPC");
    var Pago60CPC = $("#Pago60CPC");
    var MontoMaximo24CPC = $("#MontoMaximo24CPC");
    var Pago24CPC = $("#Pago24CPC");
    var MontoMaximo36CPC = $("#MontoMaximo36CPC");
    var Pago36CPC = $("#Pago36CPC");
    var MontoMaximo48CPC = $("#MontoMaximo48CPC");
    var Pago48CPC = $("#Pago48CPC");
    var TasaCPC = $("#TasaCPC");
    var PlazoCPC = $("#PlazoCPC");
    var MontoPromesaCPC = $("#MontoPromesaCPC");
    var FechaVicitaSucursalCPC = $("#FechaVicitaSucursalCPC");
    var SucursalCPC = $("#SucursalCPC");
    var NumeroSucursalCPC = $("#NumeroSucursalCPC");
    var RegionalCPC = $("#RegionalCPC");

    var DivisionCPC = $("#DivisionCPC");
    var OfertaCPC = $("#OfertaCPC");
    var SelectVenta = $("#selectVenta");

    if (FolioCPC.val() === "") {
        alert("Debe ingresar el folio del producto");
        FolioCPC.focus();
        return;
    }
    if (MontoMaximo60CPC.val() === "") {
        alert("Debe ingresar la fecha 1");
        MontoMaximo60CPC.focus();
        return;
    }
    if (Pago60CPC.val() === "") {
        alert("Ingrese producto");
        Pago60CPC.focus();
        return;
    }
    if (MontoMaximo24CPC.val() === "") {
        alert("Debe ingresar linea actual");
        MontoMaximo24CPC.focus();
        return;
    }
    if (Pago24CPC.val() === "") {
        alert("Debe ingresar liena incremento");
        Pago24CPC.focus();
        return;
    }
    if (MontoMaximo36CPC.val() === "") {
        alert("Debe ingresar producto 2");
        MontoMaximo36CPC.focus();
        return;
    }
    if (Pago36CPC.val() === "") {
        alert("Ingrese producto 3");
        Pago36CPC.focus();
        return;
    }
    if (MontoMaximo48CPC.val() === "") {
        alert("Ingrese linea F");
        MontoMaximo48CPC.focus();
        return;
    }
    if (Pago48CPC.val() === "") {
        alert("Ingrese linea TDC");
        Pago48CPC.focus();
        return;
    }

    if (TasaCPC.val() === "") {
        alert("Ingrese RFC RVT");
        TasaCPC.focus();
        return;
    }
    if (PlazoCPC.val() === "") {
        alert("Ingrese plaza");
        PlazoCPC.focus();
        return;
    }
    if (MontoPromesaCPC.val() === "") {
        alert("Agrega el piso");
        MontoPromesaCPC.focus();
        return;
    }

    if (SelectVenta.val() === "Sucursal") {

        if (FechaVicitaSucursalCPC.val() === "") {
            alert("Ingrese cliente desde");
            FechaVicitaSucursalCPC.focus();
            return;
        }

        if (SucursalCPC.val() === "") {
            alert("Ingrese plaza");
            SucursalCPC.focus();
            return;
        }
        if (NumeroSucursalCPC.val() === "") {
            alert("Agrega el piso");
            NumeroSucursalCPC.focus();
            return;
        }
        if (RegionalCPC.val() === "") {
            alert("Ingrese RegionalCPC");
            RegionalCPC.focus();
            return;
        }
        if (DivisionCPC.val() === "") {
            alert("Ingrese DivisionCPC");
            DivisionCPC.focus();
            return;
        }
    } else if (SelectVenta.val() === "Seleccione...") {
        alert("Ingrese tipo de venta");
        $("#selectVentaCNC").focus();
        return
    }


    var CpcEstatusVenta = "";
    if (UserType == 6) {//si es valdiador
        CpcEstatusVenta = $("#CpcEstatusVenta").val();
        if (CpcEstatusVenta == 0) {
            alert("Seleccione estatus de la venta");
            $("#CpcEstatusVenta").focus();
            return;
        }
    }

    var NumeroCliente = $("#Cliente");
    var Nombres = $("#Nombres");
    var ApellidoPaterno = $("#ApellidoPaterno");
    var ApellidoMaterno = $("#ApellidoMaterno");
    var FechaNacimiento = $("#FechaNacimiento");
    var RFC = $("#RFC");
    var Calle = $("#Calle");
    var NumeroExterior = $("#NumeroExterior");
    var NumeroInterior = $("#NumeroInterior");
    var CodigoPostal = $("#CodigoPostal");
    var Colonia = $("#Colonia");
    var Municipios = $("#Municipio");
    var Estados = $("#Estado");
    var Celular = $("#Celular");
    var TelefonoCasa = $("#TelefonoCasa");


    if (Nombres.val() === "") {
        alert("Debe ingresar nombre del cliente");
        Nombres.focus();
        return;
    }
    if (ApellidoPaterno.val() === "") {
        alert("Debe ingresar apellido paterno");
        ApellidoPaterno.focus();
        return;
    }
    if (ApellidoMaterno.val() === "") {
        alert("Debe ingresar apellido materno");
        ApellidoMaterno.focus();
        return;
    }
    if (FechaNacimiento.val() === "") {
        alert("Debe seleccionar fecha de nacimiento");
        FechaNacimiento.focus();
        return;
    }
    if (RFC.val() === "") {
        alert("Debe ingresarb un RFC");
        RFC.focus();
        return;
    }
    if (Calle.val() === "") {
        alert("Debe ingresar calle del cliente");
        Calle.focus();
        return;
    }
    if (NumeroExterior.val() === "") {
        alert("Ingrese numero exterior");
        NumeroExterior.focus();
        return;
    }
    if (NumeroInterior.val() === "") {
        alert("Ingrese numero interior");
        NumeroInterior.focus();
        return;
    }
    if (CodigoPostal.val() === "") {
        alert("Ingrese codigo postal");
        CodigoPostal.focus();
        return;
    }
    if (Estados.val() == 0) {
        alert("Seleccione un estado");
        Estados.focus();
        return;
    }
    if (Municipios.val() == 0) {
        alert("Seleccione un municipio");
        Municipios.focus();
        return;
    }
    if (Colonia.val() == 0) {
        alert("Ingrese Colonia");
        Colonia.focus();
        return;
    }

    //(1) Mantenimiento 04 marzo 2019
    //(1) Mantenimiento 15 marzo 2019: Oferta: OfertaCPC.val(),
    var json = {
        Id: Id.val(),
        NumeroCliente: NumeroCliente.val(),
        Nombre: Nombres.val(),
        ApellidoPaterno: ApellidoPaterno.val(),
        ApellidoMaterno: ApellidoMaterno.val(),
        FechaNacimiento: FechaNacimiento.val(),
        RFC: RFC.val(),
        Calle: Calle.val(),
        NumeroExterior: NumeroExterior.val(),
        NumeroInterior: NumeroInterior.val(),
        CodigoPostal: CodigoPostal.val(),
        Colonia: Colonia.val(),
        Municipio: Municipios.val(),
        Estado: Estados.val(),
        Celular: Celular.val(),
        TelefonoCasa: TelefonoCasa.val(),
        Folio: FolioCPC.val(),
        MontoMax24: MontoMaximo24CPC.val(),
        Pago24: Pago24CPC.val(),
        MontoMax36: MontoMaximo36CPC.val(),
        Pago36: Pago36CPC.val(),
        MontoMax48: MontoMaximo48CPC.val(),
        Pago48: Pago48CPC.val(),
        MontoMax60: MontoMaximo60CPC.val(),
        Pago60: Pago60CPC.val(),
        Tasa: TasaCPC.val(),
        Plazo: PlazoCPC.val(),
        MontoPromesa: MontoPromesaCPC.val(),
        FechaVicitaSucursal: FechaVicitaSucursalCPC.val(),
        Sucursal: SucursalCPC.val(),
        NumeroSucursal: NumeroSucursalCPC.val(),
        EstatusVenta: CpcEstatusVenta,

        Division: DivisionCPC.val(),
        Oferta: OfertaCPC.val(),

        Regional: RegionalCPC.val(),
        SeleccionaVenta: SelectVenta.val()
    };
    datos = json;
    saveCpcData(json);
}


function saveCpcData(json) {
    showLoader();
    $.ajax({
        url: hostInit + '/Client/SaveCpcData',
        type: 'POST',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            //cambiar color
            noValidado("EstadoCpc", "HeadingCpc", "ValidarCpc", "SaveCpc");
            hideLoader();
            ValidarGrupo();
        },
        error: function (error) {
            console.log("Ocurrio un error al guardar los dao");
            hideLoader();
        }
    });
}

function ValidarCpc() {
    var UserName = $("#UserCpc");
    var Password = $("#PasswordCpc");

    if (UserName.val() === "") {
        UserName.focus();
        return;
    }
    if (Password.val() === "") {
        Password.focus();
        return;
    }
    var json = {
        UserName: UserName.val(),
        Password: Password.val()
    };
    var itemSelect = document.getElementById("StatusSaleCpc");
    if (itemSelect.options[itemSelect.selectedIndex].value == 0) {
        alert("Debe seleccionar un estado de la venta al validar");
        return;
    }
    showLoader();
    $.ajax({
        url: hostInit + "/User/LogIn",
        type: 'POST',
        crossDomain: 'true',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            if (response === "No existe") {
                alert("Usuario o contraseña incorrecto(s)");
                UserName.val("");
                Password.val("");
                UserName.focus();
                hideLoader();
                return;
            }
            if (response['Tipo'] == 6 || response['Tipo'] == 4) {
                datos['EstatusVenta'] = $("#StatusSaleCpc").val();
                $.ajax({
                    url: hostInit + '/Client/SaveCpcData',
                    type: 'POST',
                    contentType: 'application/json;charset=utf-8',
                    data: JSON.stringify(datos),
                    success: function (response) {
                        if (datos['EstatusVenta'] == 2) {//no venta
                            noVendido("EstadoCpc", "HeadingCpc", "ValidarCpc", "SaveCpc");
                            ValidarGrupo();
                        } else {
                            ventaExitosa("EstadoCpc", "HeadingCpc", "ValidarCpc", "SaveCpc");
                            setFieldsCpc("disabled");
                            $("#collapse3").collapse('hide');
                        }
                        $("#StatusSaleCpc").val(0);
                        hideLoader();
                    },
                    error: function (error) {
                        console.log("Ocurrio un error al guardar los dao");
                        hideLoader();
                    }
                });
            } else {
                alert("No tiene los privilegios de validador");
                hideLoader();
            }
            UserName.val("");
            Password.val("");
        },
        error: function (error) {
            alert("error al entrar como validador");
            hideLoader();
        }
    });
}

function FinloadBranchOfficeCPC(mun, dia) {
    var json = {
        Valor: mun,
        Texto: dia
    }
    $.ajax({
        url: hostInit + '/Client/FinloadBranchOffice',
        type: 'POST',
        contentType: 'application/json;charset=utf-8',
        data: JSON.stringify(json),
        success: function (response) {
            var tableContent = '';
            sucursalesCnc = new Array();
            if (dia == 1) {
                $("#headerTableSucursalCPC").append(
                    '<th id="colSabApCPC" class="small">SABADOS AP</th>' +
                    '<th id="colSabCieCPC" class="small">SABADOS CIE</th>'
                );
                for (var i in response) {
                    tableContent += '<tr>';
                    tableContent += '<td class="small"><a style="cursor: pointer" onclick="seleccionarSucCPC(' + response[i].SIRH + ')">' + response[i].SIRH + '<a></td>';
                    tableContent += '<td class="small">' + response[i].NOMBRE_DISPOSITIVO + '</td>';
                    tableContent += '<td class="small">' + response[i].DIVISION + '</td>';
                    tableContent += '<td class="small">' + response[i].DIRECCION + '</td>';
                    tableContent += '<td class="small">' + response[i].DOMICILIO + '</td>';
                    tableContent += '<td class="small">' + response[i].COLONIA + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE1 + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE2 + '</td>';
                    tableContent += '<td class="small">' + response[i].DELEG_MUNIC + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_AP + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_CIE + '</td>';
                    tableContent += '<td class="small">' + response[i].SABADOS_AP + '</td>';
                    tableContent += '<td class="small">' + response[i].SABADOS_CIE + '</td>';
                    tableContent += '</tr>';
                    sucursalesCnc.push(response[i]);
                }
            } else {
                $("#colSabApCPC").remove();
                $("#colSabCieCPC").remove();
                for (var i in response) {
                    tableContent += '<tr>';
                    tableContent += '<td class="small"><a style="cursor: pointer" onclick="seleccionarSucCPC(' + response[i].SIRH + ')">' + response[i].SIRH + '<a></td>';
                    tableContent += '<td class="small">' + response[i].NOMBRE_DISPOSITIVO + '</td>';
                    tableContent += '<td class="small">' + response[i].DIVISION + '</td>';
                    tableContent += '<td class="small">' + response[i].DIRECCION + '</td>';
                    tableContent += '<td class="small">' + response[i].DOMICILIO + '</td>';
                    tableContent += '<td class="small">' + response[i].COLONIA + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE1 + '</td>';
                    tableContent += '<td class="small">' + response[i].CALLE2 + '</td>';
                    tableContent += '<td class="small">' + response[i].DELEG_MUNIC + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_AP + '</td>';
                    tableContent += '<td class="small">' + response[i].LUNES_VIERNES_CIE + '</td>';
                    tableContent += '</tr>';
                    sucursalesCnc.push(response[i]);
                }
            }

            $("#bodyTableSucCPC").html(tableContent);
            $('#myModalSucursalesCPC').modal('show');
        },
        error: function (reject) {
            console.log(reject);
        }
    });
}

function seleccionarSucCPC(SIRH) {
    for (var i in sucursalesCnc) {
        if (sucursalesCnc[i].SIRH == SIRH) {
            $("#DivisionCPC").val(sucursalesCnc[i].DIVISION);
            $("#RegionalCPC").val(sucursalesCnc[i].DIRECCION);
            $("#NumeroSucursalCPC").val(sucursalesCnc[i].SIRH);
            $("#SucursalCPC").val(sucursalesCnc[i].NOMBRE_DISPOSITIVO);
            break;
        }
    }
    $('#myModalSucursalesCPC').modal('hide');
}

function CambiarTipoVenta() {
    var cod = document.getElementById("selectVenta").value;
    if (cod == "Sucursal") {
        document.getElementById("divFechaSuc").hidden = false;
        document.getElementById("divEstado").hidden = false;
        document.getElementById("divCompletaSuc1").hidden = false;
        document.getElementById("divRegional").hidden = false;
        document.getElementById("divDivision").hidden = false;

    } else {
        document.getElementById("divCompletaSuc1").hidden = true;
        document.getElementById("divFechaSuc").hidden = true;
        document.getElementById("divEstado").hidden = true;
        document.getElementById("divCompletaSuc1").hidden = true;
        document.getElementById("divRegional").hidden = true;
        document.getElementById("divDivision").hidden = true;
    }
}