﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRM_V1.Models
{
    public class Municipio
    {
        public long Id { get; set; }
        public string Clave { get; set; }
        public string Nombre { get; set; }
    }
}