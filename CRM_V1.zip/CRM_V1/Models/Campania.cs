﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CRM_V1.Models
{
    public class Campania
    {
        public string NombreCampania { get; set; }
        public string New { get; set; }
    }
}