﻿using CRM_V1.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CRM_V1.Controllers
{
    public class UserController : Controller
    {
        public static TipoUsuario Tipo;
        [Route("/User/LogIn")]
        public Object LogIn(User user)
        {
            try
            {
                string cadString = ConfigurationManager.ConnectionStrings["Data"].ConnectionString;
                SqlConnection con = new SqlConnection(cadString);
                con.Open();
                SqlCommand cmd = new SqlCommand("LogIn", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", user.UserName);
                cmd.Parameters.AddWithValue("@Password", user.Password);
                SqlDataReader dataReader = cmd.ExecuteReader();
                if (!dataReader.HasRows)
                {
                    return ToJson("No existe");
                }
                dataReader.Read();
                user = new User
                {
                    Password = dataReader["PASSWORD"].ToString(),
                    UserName = dataReader["Usuario"].ToString(),
                    Id = long.Parse(dataReader["Id_Usuario"].ToString()),
                    Tipo = (TipoUsuario)int.Parse(dataReader["Id_Tipo"].ToString()),
                    Name = dataReader["Nombre"].ToString(),
                    LastName1 = dataReader["ApPaterno"].ToString(),
                    LastName2 = dataReader["ApMaterno"].ToString()
                };

                Session.Timeout = 20000;
                Session["Tipo"] = user.Tipo;
                if (user.Tipo==TipoUsuario.RVT)
                {
                    Session["IdUser"] = user.Id;
                }
                else
                {
                    Session["IdValidador"] = user.Id;
                }
                Tipo = user.Tipo;
                return ToJson(user);
            }
            catch (Exception ex)
            {
                return "Error: " + ex;
            }
        }

        public JsonResult ToJson(Object obj)
        {
            //return null;
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
    }
}